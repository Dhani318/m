import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'tools/attack_tools.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'dart:typed_data';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void initializeNotifications() async {
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');
  
  const InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
  );
  
  await flutterLocalNotificationsPlugin.initialize(initializationSettings);
}

class HomePage extends StatefulWidget {
  final Map<String, dynamic> user;

  const HomePage({super.key, required this.user});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late VideoPlayerController _controller;
  double _dragPosition = 0.0;
  
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/banner.mp4')
      ..initialize().then((_) {
        setState(() {});
        _controller.setLooping(true);
        _controller.setVolume(0.0);
        _controller.play();
      });
      
    initializeNotifications();
    FlutterDownloader.initialize();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0A0015),
              Color(0xFF1A0025),
              Color(0xFF0A0015),
            ],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: const EdgeInsets.only(bottom: 30),
                child: const Center(
                  child: Column(
                    children: [
                      Text(
                        'ZERO EXTERNAL',
                        style: TextStyle(
                          fontSize: 32,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFFFF0040),
                          letterSpacing: 3,
                          shadows: [
                            Shadow(
                              color: Color(0xFFFF0040),
                              blurRadius: 15,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'developer @amxazink',
                        style: TextStyle(
                          color: Color(0xFF888888),
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 1,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              Container(
                height: 280,
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 30),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(color: const Color(0xFFFF0040), width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFF0040).withOpacity(0.3),
                      blurRadius: 20,
                      spreadRadius: 2,
                      offset: const Offset(0, 8),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(23),
                  child: _controller.value.isInitialized
                      ? AspectRatio(
                          aspectRatio: _controller.value.aspectRatio,
                          child: VideoPlayer(_controller),
                        )
                      : Container(
                          color: const Color(0xFF0A0015),
                          child: const Center(
                            child: CircularProgressIndicator(color: Color(0xFFFF0040)),
                          ),
                        ),
                ),
              ),

              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 30),
                padding: const EdgeInsets.all(25),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFF6A0DAD),
                      Color(0xFF8B008B),
                      Color(0xFFFF0040),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(25),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.6),
                      blurRadius: 20,
                      spreadRadius: 2,
                      offset: const Offset(0, 10),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    _buildUserInfoItem(Icons.person_rounded, 'Username:', widget.user['username'] ?? 'dinzzx1'),
                    _buildUserInfoItem(Icons.verified_user_rounded, 'Role:', widget.user['role'] ?? 'User'),
                    _buildUserInfoItem(Icons.calendar_month_rounded, 'Expired:', widget.user['expired'] ?? 'Never'),
                    _buildUserInfoItem(FontAwesomeIcons.whatsapp, 'My Sender:', widget.user['sender'] ?? '0'),
                  ],
                ),
              ),

              Container(
                height: 2,
                margin: const EdgeInsets.only(bottom: 25),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.transparent,
                      const Color(0xFFFF0040),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
              
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                child: Text(
                  'Quick Actions',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFFFF0040),
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              
              GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 2,
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                children: _buildQuickActions(),
              ),
              
              const SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildQuickActions() {
    final role = widget.user['role']?.toString().toLowerCase() ?? 'user';
    final List<Widget> actions = [
      _buildActionButton(FontAwesomeIcons.whatsapp, 'WhatsApp Attack', () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => AttackPage(user: widget.user)));
      }),
      _buildActionButton(FontAwesomeIcons.whatsapp, 'Sender Manager', () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => SenderManagerPage(user: widget.user)));
      }),
      _buildActionButton(Icons.music_note, 'Music Player', () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => MusicTabPage(user: widget.user)));
      }),
    ];
    
    if (role == 'owner' || role == 'admin' || role == 'reseller') {
      actions.add(_buildActionButton(Icons.person_add_rounded, 'User Manager', () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => UserManagerPage(userRole: role)));
      }));
    }
    
    return actions;
  }

  Widget _buildUserInfoItem(IconData icon, String label, String value) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFFF0040), size: 22),
          const SizedBox(width: 15),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 15,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              value.replaceAll('}', ''),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 15,
              ),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(IconData icon, String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              Color(0xFF1A0025),
              Color(0xFF2A0035),
            ],
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 15,
              spreadRadius: 1,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFFF0040).withOpacity(0.1),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
              ),
              child: Icon(icon, color: const Color(0xFFFF0040), size: 28),
            ),
            const SizedBox(height: 12),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w800,
                fontSize: 13,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SenderManagerPage extends StatefulWidget {
  final Map<String, dynamic> user;

  const SenderManagerPage({super.key, required this.user});

  @override
  State<SenderManagerPage> createState() => _SenderManagerPageState();
}

class _SenderManagerPageState extends State<SenderManagerPage> {
  int _currentTab = 0;
  final TextEditingController _botNumberController = TextEditingController();
  bool _isLoading = false;
  List<dynamic> _senders = [];
  String? _pairingCode;
  bool _showPairingCode = false;
  String _connectionStatus = 'Waiting for pairing...';
  Timer? _pairingTimer;
  int _notificationId = 1000;

  @override
  void initState() {
    super.initState();
    _loadSenders();
  }

  @override
  void dispose() {
    _pairingTimer?.cancel();
    super.dispose();
  }

  Future<void> _showPairingNotification(String code) async {
    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'whatsapp_pairing_channel',
      'WhatsApp Pairing',
      channelDescription: 'Notifications for WhatsApp pairing process',
      importance: Importance.high,
      priority: Priority.high,
      ticker: 'WhatsApp Pairing Code',
      color: const Color(0xFF25D366),
      ledColor: const Color(0xFF25D366),
      ledOnMs: 1000,
      ledOffMs: 500,
      enableVibration: true,
      vibrationPattern: Int64List.fromList([0, 500, 200, 500]),
      playSound: true,
      sound: const RawResourceAndroidNotificationSound('whatsapp_notification'),
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.status,
      timeoutAfter: 30000,
      styleInformation: BigTextStyleInformation(
        'Your WhatsApp pairing code is: $code\nOpen WhatsApp on your phone and enter this code to connect your sender.',
        htmlFormatBigText: true,
        contentTitle: 'WhatsApp Pairing Required',
        summaryText: 'Pairing Code: $code',
      ),
    );

    final platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await flutterLocalNotificationsPlugin.show(
      _notificationId++,
      'WhatsApp Pairing Code',
      'Use code: $code to connect your WhatsApp',
      platformChannelSpecifics,
      payload: 'whatsapp_pairing_$code',
    );
  }

  Future<void> _showConnectionSuccessNotification(String botNumber) async {
    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'whatsapp_connection_channel',
      'WhatsApp Connection',
      channelDescription: 'Notifications for WhatsApp connection status',
      importance: Importance.high,
      priority: Priority.high,
      ticker: 'WhatsApp Connected',
      color: const Color(0xFF25D366),
      ledColor: const Color(0xFF25D366),
      ledOnMs: 1000,
      ledOffMs: 500,
      enableVibration: true,
      vibrationPattern: Int64List.fromList([0, 250, 250, 250]),
      playSound: true,
      sound: const RawResourceAndroidNotificationSound('whatsapp_connected'),
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.status,
      timeoutAfter: 5000,
      styleInformation: BigTextStyleInformation(
        'WhatsApp sender $botNumber has been successfully connected!\nYou can now use this sender for WhatsApp attacks.',
        htmlFormatBigText: true,
        contentTitle: 'WhatsApp Connected Successfully',
        summaryText: 'Sender $botNumber is ready',
      ),
    );

    final platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await flutterLocalNotificationsPlugin.show(
      _notificationId++,
      'WhatsApp Connected!',
      'Sender $botNumber is now ready to use',
      platformChannelSpecifics,
      payload: 'whatsapp_connected_$botNumber',
    );
  }

  Future<void> _cancelPairingNotification() async {
    await flutterLocalNotificationsPlugin.cancelAll();
  }

  Future<void> _loadSenders() async {
    try {
      final response = await http.get(
        Uri.parse('http://157.245.159.165:4000/senders?username=${widget.user['username']}'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _senders = data['senders'] ?? [];
        });
      }
    } catch (e) {
      print('Error loading senders: $e');
    }
  }

  Widget _buildPairingCodeSection() {
    if (!_showPairingCode || _pairingCode == null) {
      return const SizedBox();
    }

    Color statusColor = Colors.orange;
    if (_connectionStatus.contains('Connected')) {
      statusColor = Colors.green;
    } else if (_connectionStatus.contains('Error') || _connectionStatus.contains('Failed')) {
      statusColor = const Color(0xFFFF0040);
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'WhatsApp Pairing Code',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
              fontSize: 16,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Use this code to pair your WhatsApp account in the WhatsApp app',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFFF0040).withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFFF0040)),
            ),
            child: Center(
              child: Text(
                _formatPairingCode(_pairingCode!),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                _connectionStatus,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (!_connectionStatus.contains('Connected') && !_connectionStatus.contains('Error'))
            const LinearProgressIndicator(
              backgroundColor: Colors.black,
              valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFFF0040)),
            ),
          const SizedBox(height: 12),
          TextButton.icon(
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Pairing code copied to clipboard'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            icon: const Icon(Icons.notifications_active, color: Color(0xFF25D366), size: 18),
            label: const Text(
              'Notification sent to your device',
              style: TextStyle(
                color: Color(0xFF25D366),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatPairingCode(String code) {
    if (code.length == 8) {
      return '${code.substring(0, 4)}-${code.substring(4)}';
    }
    return code;
  }

  Future<void> _addSender() async {
    if (_botNumberController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter bot number'),
          backgroundColor: Color(0xFFFF0040),
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse('http://157.245.159.165:4000/addsender'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'botNumber': _botNumberController.text,
          'username': widget.user['username'],
        }),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['pairingCode'] != null) {
          setState(() {
            _pairingCode = data['pairingCode'];
            _showPairingCode = true;
            _connectionStatus = 'Connecting to WhatsApp...';
          });
          
          await _showPairingNotification(_pairingCode!);
          
          _startPairingStatusCheck(_botNumberController.text);
        }
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('WhatsApp sender added successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        _botNumberController.clear();
        _loadSenders();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to add WhatsApp sender'),
            backgroundColor: Color(0xFFFF0040),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: const Color(0xFFFF0040),
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _startPairingStatusCheck(String botNumber) {
    const checkInterval = Duration(seconds: 3);
    int checkCount = 0;
    const maxChecks = 60;

    _pairingTimer?.cancel();
    _pairingTimer = Timer.periodic(checkInterval, (Timer timer) async {
      if (checkCount >= maxChecks) {
        timer.cancel();
        if (mounted) {
          setState(() {
            _connectionStatus = 'Connection timeout. Please try again.';
          });
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Pairing timeout. Please try again.'),
              backgroundColor: Color(0xFFFF0040),
            ),
          );
        }
        return;
      }

      try {
        final response = await http.get(
          Uri.parse('http://157.245.159.165:4000/check-session?botNumber=${Uri.encodeComponent(botNumber)}'),
        );

        if (mounted) {
          if (response.statusCode == 200) {
            final data = json.decode(response.body);
            
            if (data['connected'] == true) {
              timer.cancel();
              setState(() {
                _connectionStatus = 'Connected Successfully!';
              });
              
              await _cancelPairingNotification();
              await _showConnectionSuccessNotification(botNumber);
              
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('WhatsApp connected successfully!'),
                  backgroundColor: Colors.green,
                ),
              );
              
              _loadSenders();
              
              Future.delayed(const Duration(seconds: 2), () {
                if (mounted) {
                  setState(() {
                    _showPairingCode = false;
                  });
                }
              });
              
            } else if (data['connecting'] == true) {
              setState(() {
                _connectionStatus = 'Connecting to WhatsApp... (${checkCount + 1}/$maxChecks)';
              });
            } else if (data['error'] != null) {
              timer.cancel();
              setState(() {
                _connectionStatus = 'Error: ${data['error']}';
              });
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Connection error: ${data['error']}'),
                  backgroundColor: const Color(0xFFFF0040),
                ),
              );
            }
          } else {
            timer.cancel();
            setState(() {
              _connectionStatus = 'Failed to check connection status';
            });
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Failed to check connection status'),
                backgroundColor: Color(0xFFFF0040),
              ),
            );
          }
        }
      } catch (e) {
        if (mounted) {
          timer.cancel();
          setState(() {
            _connectionStatus = 'Network error: $e';
          });
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Network error: $e'),
              backgroundColor: const Color(0xFFFF0040),
            ),
          );
        }
      }
      checkCount++;
    });
  }

  Future<void> _deleteSender(String senderId) async {
    try {
      final response = await http.delete(
        Uri.parse('http://157.245.159.165:4000/sender/$senderId'),
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Sender deleted successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        _loadSenders();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to delete sender'),
            backgroundColor: Color(0xFFFF0040),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: const Color(0xFFFF0040),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0015),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFFF0040)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Sender Manager',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1A0025),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Row(
              children: [
                _buildTabButton(0, 'Add Sender'),
                _buildTabButton(1, 'My Senders'),
              ],
            ),
          ),
          Expanded(
            child: _currentTab == 0 ? _buildAddSenderTab() : _buildSendersListTab(),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String text) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _currentTab = index;
          });
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _currentTab == index ? const Color(0xFFFF0040) : Colors.transparent,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _currentTab == index ? Colors.white : const Color(0xFF888888),
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAddSenderTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          _buildPairingCodeSection(),
          Container(
            padding: const EdgeInsets.all(25),
            decoration: BoxDecoration(
              color: const Color(0x101A0025),
              borderRadius: BorderRadius.circular(25),
              border: Border.all(color: const Color(0x30FFFFFF)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 30,
                  spreadRadius: 2,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Column(
              children: [
                const Row(
                  children: [
                    Icon(FontAwesomeIcons.whatsapp, color: Color(0xFFFF0040), size: 28),
                    SizedBox(width: 12),
                    Text(
                      'ADD WHATSAPP SENDER',
                      style: TextStyle(
                        color: Color(0xFFFF0040),
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 25),
                TextField(
                  controller: _botNumberController,
                  style: const TextStyle(
                    color: Colors.white, 
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Bot Number (e.g., 6281234567890)',
                    labelStyle: const TextStyle(
                      color: Color(0xFF888888),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: const Color(0x20FFFFFF),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0xFFFF0040),
                        width: 2,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0x30FFFFFF),
                      ),
                    ),
                    prefixIcon: const Icon(
                      Icons.phone_android_rounded,
                      color: Color(0xFFFF0040),
                      size: 22,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 18,
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _addSender,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF0040),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 8,
                      shadowColor: const Color(0xFFFF0040).withOpacity(0.5),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            height: 24,
                            width: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 3,
                            ),
                          )
                        : const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(FontAwesomeIcons.whatsapp, size: 20),
                              SizedBox(width: 12),
                              Text(
                                'ADD SENDER',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 16,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSendersListTab() {
    return _senders.isEmpty
        ? const Center(
            child: Text(
              'No senders found',
              style: TextStyle(
                color: Color(0xFF888888),
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _senders.length,
            itemBuilder: (context, index) {
              final sender = _senders[index];
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A0025),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(FontAwesomeIcons.whatsapp, color: Color(0xFFFF0040), size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            sender['botNumber'] ?? 'Unknown',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Status: ${sender['status'] ?? 'Unknown'}',
                            style: const TextStyle(
                              color: Color(0xFF888888),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => _deleteSender(sender['id']),
                      icon: const Icon(Icons.delete_rounded, color: Color(0xFFFF0040)),
                    ),
                  ],
                ),
              );
            },
          );
  }
}

class UserManagerPage extends StatefulWidget {
  final String userRole;

  const UserManagerPage({super.key, required this.userRole});

  @override
  State<UserManagerPage> createState() => _UserManagerPageState();
}

class _UserManagerPageState extends State<UserManagerPage> {
  int _currentTab = 0;
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _expiryController = TextEditingController();
  String _selectedRole = '';
  bool _isLoading = false;
  List<dynamic> _users = [];

  List<String> get _availableRoles {
    switch (widget.userRole) {
      case 'owner':
        return ['admin', 'reseller', 'user'];
      case 'admin':
        return ['reseller', 'user'];
      case 'reseller':
        return ['user'];
      default:
        return [];
    }
  }

  bool _canDeleteUser(String targetUserRole) {
    switch (widget.userRole) {
      case 'owner':
        return targetUserRole != 'owner';
      case 'admin':
        return targetUserRole == 'reseller' || targetUserRole == 'user';
      case 'reseller':
        return targetUserRole == 'user';
      default:
        return false;
    }
  }

  @override
  void initState() {
    super.initState();
    _loadUsers();
  }

  Future<void> _loadUsers() async {
    try {
      final response = await http.get(
        Uri.parse('http://157.245.159.165:4000/users'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _users = data['users'] ?? [];
        });
      }
    } catch (e) {
      print('Error loading users: $e');
    }
  }

  Future<void> _addUser() async {
    if (_usernameController.text.isEmpty ||
        _passwordController.text.isEmpty ||
        _selectedRole.isEmpty ||
        _expiryController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill all fields'),
          backgroundColor: Color(0xFFFF0040),
        ),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.post(
        Uri.parse('http://157.245.159.165:4000/adduser'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'username': _usernameController.text,
          'password': _passwordController.text,
          'role': _selectedRole,
          'expiry': _expiryController.text,
        }),
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('User created successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        _usernameController.clear();
        _passwordController.clear();
        _expiryController.clear();
        setState(() {
          _selectedRole = '';
        });
        _loadUsers();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to create user'),
            backgroundColor: Color(0xFFFF0040),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: const Color(0xFFFF0040),
        ),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _deleteUser(String username, String userRole) async {
    if (!_canDeleteUser(userRole)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You do not have permission to delete this user'),
          backgroundColor: Color(0xFFFF0040),
        ),
      );
      return;
    }

    try {
      final response = await http.delete(
        Uri.parse('http://157.245.159.165:4000/user/$username'),
      );

      if (response.statusCode == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('User deleted successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        _loadUsers();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to delete user'),
            backgroundColor: Color(0xFFFF0040),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: const Color(0xFFFF0040),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0015),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFFF0040)),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'User Manager',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1A0025),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Row(
              children: [
                _buildTabButton(0, 'Add User'),
                _buildTabButton(1, 'User List'),
              ],
            ),
          ),
          Expanded(
            child: _currentTab == 0 ? _buildAddUserTab() : _buildUsersListTab(),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String text) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _currentTab = index;
          });
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _currentTab == index ? const Color(0xFFFF0040) : Colors.transparent,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _currentTab == index ? Colors.white : const Color(0xFF888888),
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAddUserTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(25),
            decoration: BoxDecoration(
              color: const Color(0x101A0025),
              borderRadius: BorderRadius.circular(25),
              border: Border.all(color: const Color(0x30FFFFFF)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 30,
                  spreadRadius: 2,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Column(
              children: [
                const Row(
                  children: [
                    Icon(Icons.person_add_rounded, color: Color(0xFFFF0040), size: 28),
                    SizedBox(width: 12),
                    Text(
                      'ADD NEW USER',
                      style: TextStyle(
                        color: Color(0xFFFF0040),
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 25),
                TextField(
                  controller: _usernameController,
                  style: const TextStyle(
                    color: Colors.white, 
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Username',
                    labelStyle: const TextStyle(
                      color: Color(0xFF888888),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: const Color(0x20FFFFFF),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0xFFFF0040),
                        width: 2,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0x30FFFFFF),
                      ),
                    ),
                    prefixIcon: const Icon(
                      Icons.person_rounded,
                      color: Color(0xFFFF0040),
                      size: 22,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 18,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  style: const TextStyle(
                    color: Colors.white, 
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Password',
                    labelStyle: const TextStyle(
                      color: Color(0xFF888888),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: const Color(0x20FFFFFF),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0xFFFF0040),
                        width: 2,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0x30FFFFFF),
                      ),
                    ),
                    prefixIcon: const Icon(
                      Icons.lock_rounded,
                      color: Color(0xFFFF0040),
                      size: 22,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 18,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: const Color(0x20FFFFFF),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: const Color(0x30FFFFFF)),
                  ),
                  child: DropdownButton<String>(
                    value: _selectedRole.isEmpty ? null : _selectedRole,
                    hint: const Text(
                      'Select Role',
                      style: TextStyle(
                        color: Color(0xFF888888),
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    isExpanded: true,
                    dropdownColor: const Color(0xFF1A0025),
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                    items: _availableRoles.map((role) {
                      return DropdownMenuItem(
                        value: role,
                        child: Text(role.toUpperCase()),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        _selectedRole = value!;
                      });
                    },
                    underline: const SizedBox(),
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: _expiryController,
                  keyboardType: TextInputType.number,
                  style: const TextStyle(
                    color: Colors.white, 
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Expiry Days (1-365)',
                    labelStyle: const TextStyle(
                      color: Color(0xFF888888),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: const Color(0x20FFFFFF),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0xFFFF0040),
                        width: 2,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0x30FFFFFF),
                      ),
                    ),
                    prefixIcon: const Icon(
                      Icons.calendar_month_rounded,
                      color: Color(0xFFFF0040),
                      size: 22,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 18,
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _addUser,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF0040),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 8,
                      shadowColor: const Color(0xFFFF0040).withOpacity(0.5),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            height: 24,
                            width: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 3,
                            ),
                          )
                        : const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.person_add_rounded, size: 20),
                              SizedBox(width: 12),
                              Text(
                                'CREATE USER',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 16,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUsersListTab() {
    return _users.isEmpty
        ? const Center(
            child: Text(
              'No users found',
              style: TextStyle(
                color: Color(0xFF888888),
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _users.length,
            itemBuilder: (context, index) {
              final user = _users[index];
              final userRole = user['role']?.toString().toLowerCase() ?? 'user';
              final canDelete = _canDeleteUser(userRole);
              
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A0025),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.person_rounded, color: Color(0xFFFF0040), size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            user['username'] ?? 'Unknown',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Role: ${user['role'] ?? 'Unknown'} | Expired: ${user['expired'] ?? 'Unknown'}',
                            style: const TextStyle(
                              color: Color(0xFF888888),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    if (canDelete)
                      IconButton(
                        onPressed: () => _deleteUser(user['username'], userRole),
                        icon: const Icon(Icons.delete_rounded, color: Color(0xFFFF0040)),
                      ),
                  ],
                ),
              );
            },
          );
  }
}

class MusicTabPage extends StatefulWidget {
  final Map<String, dynamic> user;

  const MusicTabPage({super.key, required this.user});

  @override
  State<MusicTabPage> createState() => _MusicTabPageState();
}

class _MusicTabPageState extends State<MusicTabPage> {
  int _currentTab = 0;
  final TextEditingController _searchController = TextEditingController();
  final AudioPlayer _audioPlayer = AudioPlayer();
  bool _isLoading = false;
  bool _isPlaying = false;
  bool _isDownloading = false;
  String _errorMessage = '';
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  int _musicNotificationId = 2000;
  
  Map<String, dynamic>? _currentMusic;
  List<Map<String, dynamic>> _searchHistory = [];
  List<Map<String, dynamic>> _downloadedMusic = [];
  String? _thumbnailUrl;

  @override
  void initState() {
    super.initState();
    _setupAudioPlayer();
    _loadDownloadedMusic();
  }

  void _setupAudioPlayer() {
    _audioPlayer.onPlayerStateChanged.listen((state) {
      setState(() {
        _isPlaying = state == PlayerState.playing;
      });
      
      if (_currentMusic != null) {
        if (state == PlayerState.playing) {
          _showNowPlayingNotification();
        } else if (state == PlayerState.paused) {
          _updateNotificationForPause();
        }
      }
    });

    _audioPlayer.onDurationChanged.listen((duration) {
      setState(() {
        _duration = duration;
      });
    });

    _audioPlayer.onPositionChanged.listen((position) {
      setState(() {
        _position = position;
      });
    });

    _audioPlayer.onPlayerComplete.listen((event) {
      setState(() {
        _isPlaying = false;
        _position = Duration.zero;
      });
      
      _showMusicCompleteNotification();
    });
  }

  Future<void> _loadDownloadedMusic() async {
    try {
      final directory = await getApplicationDocumentsDirectory();
      final musicDir = Directory('${directory.path}/music');
      
      if (await musicDir.exists()) {
        final files = await musicDir.list().toList();
        _downloadedMusic.clear();
        
        for (var file in files) {
          if (file.path.endsWith('.mp3')) {
            _downloadedMusic.add({
              'title': file.path.split('/').last.replaceAll('.mp3', ''),
              'path': file.path,
              'isDownloaded': true,
            });
          }
        }
        setState(() {});
      }
    } catch (e) {
      print('Error loading downloaded music: $e');
    }
  }

  Future<void> _showNowPlayingNotification() async {
    if (_currentMusic == null) return;

    final String title = _currentMusic!['title'] ?? 'Unknown';
    final String artist = _currentMusic!['author'] ?? 'Unknown Artist';

    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'music_player_channel',
      'Music Player',
      channelDescription: 'Notifications for music player',
      importance: Importance.high,
      priority: Priority.high,
      ticker: 'Now Playing: $title',
      color: const Color(0xFFFF0040),
      ledColor: const Color(0xFFFF0040),
      ledOnMs: 1000,
      ledOffMs: 500,
      enableVibration: true,
      vibrationPattern: Int64List.fromList([0, 250, 250, 250]),
      playSound: false,
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.transport,
      timeoutAfter: 0,
      autoCancel: false,
      ongoing: true,
      showWhen: false,
      showProgress: false,
      onlyAlertOnce: false,
      actions: [
        const AndroidNotificationAction(
          'pause_action',
          'Pause',
          titleColor: Color(0xFFFF0040),
        ),
        const AndroidNotificationAction(
          'stop_action',
          'Stop',
          titleColor: Color(0xFFFF0040),
        ),
      ],
      styleInformation: const MediaStyleInformation(
        htmlFormatContent: true,
        htmlFormatTitle: true,
      ),
    );

    final platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await flutterLocalNotificationsPlugin.show(
      _musicNotificationId,
      'Now Playing',
      '$title - $artist',
      platformChannelSpecifics,
      payload: 'music_playing_$title',
    );
  }

  Future<void> _updateNotificationForPause() async {
    if (_currentMusic == null) return;

    final String title = _currentMusic!['title'] ?? 'Unknown';
    final String artist = _currentMusic!['author'] ?? 'Unknown Artist';

    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'music_player_channel',
      'Music Player',
      channelDescription: 'Notifications for music player',
      importance: Importance.high,
      priority: Priority.high,
      ticker: 'Paused: $title',
      color: const Color(0xFF888888),
      ledColor: const Color(0xFF888888),
      enableVibration: false,
      playSound: false,
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.transport,
      timeoutAfter: 0,
      autoCancel: false,
      ongoing: true,
      showWhen: false,
      showProgress: false,
      onlyAlertOnce: false,
      actions: [
        const AndroidNotificationAction(
          'play_action',
          'Play',
          titleColor: Color(0xFF25D366),
        ),
        const AndroidNotificationAction(
          'stop_action',
          'Stop',
          titleColor: Color(0xFFFF0040),
        ),
      ],
    );

    final platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await flutterLocalNotificationsPlugin.show(
      _musicNotificationId,
      'Music Paused',
      '$title - $artist',
      platformChannelSpecifics,
      payload: 'music_paused_$title',
    );
  }

  Future<void> _showDownloadCompleteNotification(String title) async {
    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'music_download_channel',
      'Music Download',
      channelDescription: 'Notifications for music downloads',
      importance: Importance.high,
      priority: Priority.high,
      ticker: 'Download Complete',
      color: const Color(0xFF25D366),
      ledColor: const Color(0xFF25D366),
      ledOnMs: 1000,
      ledOffMs: 500,
      enableVibration: true,
      vibrationPattern: Int64List.fromList([0, 500, 250, 500]),
      playSound: true,
      sound: const RawResourceAndroidNotificationSound('download_complete'),
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.progress,
      timeoutAfter: 5000,
      styleInformation: BigTextStyleInformation(
        'Music "$title" has been downloaded successfully!\n\nYou can find it in your downloads section.',
        htmlFormatBigText: true,
        contentTitle: 'Download Complete',
        summaryText: 'Ready to play offline',
      ),
    );

    final platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await flutterLocalNotificationsPlugin.show(
      _musicNotificationId + 1,
      'Download Complete',
      'Music "$title" is ready',
      platformChannelSpecifics,
      payload: 'download_complete_$title',
    );
  }

  Future<void> _showMusicCompleteNotification() async {
    if (_currentMusic == null) return;

    final String title = _currentMusic!['title'] ?? 'Unknown';

    final androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'music_player_channel',
      'Music Player',
      channelDescription: 'Notifications for music player',
      importance: Importance.defaultImportance,
      priority: Priority.defaultPriority,
      ticker: 'Playback Complete',
      color: const Color(0xFF25D366),
      enableVibration: true,
      vibrationPattern: Int64List.fromList([0, 250, 250, 250]),
      playSound: true,
      sound: const RawResourceAndroidNotificationSound('playback_complete'),
      visibility: NotificationVisibility.public,
      category: AndroidNotificationCategory.transport,
      timeoutAfter: 3000,
      autoCancel: true,
    );

    final platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    await flutterLocalNotificationsPlugin.show(
      _musicNotificationId + 2,
      'Playback Complete',
      'Finished: $title',
      platformChannelSpecifics,
      payload: 'playback_complete_$title',
    );
  }

  Future<void> _clearMusicNotifications() async {
    await flutterLocalNotificationsPlugin.cancel(_musicNotificationId);
    await flutterLocalNotificationsPlugin.cancel(_musicNotificationId + 1);
    await flutterLocalNotificationsPlugin.cancel(_musicNotificationId + 2);
  }

  Future<void> _searchMusic() async {
    final query = _searchController.text.trim();
    if (query.isEmpty) {
      setState(() {
        _errorMessage = 'Please enter a search query';
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    try {
      final response = await http.get(
        Uri.parse('https://api-faa.my.id/faa/ytplay?query=${Uri.encodeComponent(query)}'),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);
        
        if (data['status'] == true) {
          setState(() {
            _currentMusic = data['result'];
            _thumbnailUrl = data['result']['thumbnail'];
            _searchHistory.insert(0, {
              'query': query,
              'title': data['result']['title'],
              'timestamp': DateTime.now(),
              'musicData': data['result'],
            });
            if (_searchHistory.length > 10) {
              _searchHistory.removeLast();
            }
          });
          
          await _playMusic(_currentMusic!['mp3']);
        } else {
          setState(() {
            _errorMessage = 'No results found';
          });
        }
      } else {
        setState(() {
          _errorMessage = 'Failed to search music';
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Error: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _playMusic(String url) async {
    try {
      await _audioPlayer.play(UrlSource(url));
      setState(() {
        _isPlaying = true;
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to play music: $e';
      });
    }
  }

  Future<void> _playDownloadedMusic(String filePath) async {
    try {
      await _audioPlayer.play(DeviceFileSource(filePath));
      setState(() {
        _isPlaying = true;
        _currentMusic = {
          'title': filePath.split('/').last.replaceAll('.mp3', ''),
          'mp3': filePath,
          'author': 'Local File',
        };
      });
    } catch (e) {
      setState(() {
        _errorMessage = 'Failed to play downloaded music: $e';
      });
    }
  }

  Future<void> _pauseMusic() async {
    await _audioPlayer.pause();
    setState(() {
      _isPlaying = false;
    });
  }

  Future<void> _stopMusic() async {
    await _audioPlayer.stop();
    setState(() {
      _isPlaying = false;
      _position = Duration.zero;
    });
    
    await _clearMusicNotifications();
  }

  void _seekTo(double value) {
    final position = Duration(seconds: value.toInt());
    _audioPlayer.seek(position);
  }

  Future<void> _downloadMusic() async {
    if (_currentMusic == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No music to download'),
          backgroundColor: Color(0xFFFF0040),
        ),
      );
      return;
    }

    setState(() {
      _isDownloading = true;
    });

    try {
      final status = await Permission.storage.request();
      if (!status.isGranted) {
        throw Exception('Storage permission denied');
      }

      final directory = await getApplicationDocumentsDirectory();
      final musicDir = Directory('${directory.path}/music');
      if (!await musicDir.exists()) {
        await musicDir.create(recursive: true);
      }

      final fileName = '${_currentMusic!['title'].replaceAll(RegExp(r'[^\w\s]'), '')}.mp3';
      final filePath = '${musicDir.path}/$fileName';
      
      final response = await http.get(Uri.parse(_currentMusic!['mp3']));
      
      if (response.statusCode == 200) {
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);
        
        await _showDownloadCompleteNotification(_currentMusic!['title']);
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Music downloaded successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        
        await _loadDownloadedMusic();
      } else {
        throw Exception('Failed to download file');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Download failed: $e'),
          backgroundColor: const Color(0xFFFF0040),
        ),
      );
    } finally {
      setState(() {
        _isDownloading = false;
      });
    }
  }

  Future<void> _deleteDownloadedMusic(String filePath) async {
    try {
      final file = File(filePath);
      if (await file.exists()) {
        await file.delete();
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Music deleted successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        
        await _loadDownloadedMusic();
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Delete failed: $e'),
          backgroundColor: const Color(0xFFFF0040),
        ),
      );
    }
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    final minutes = twoDigits(duration.inMinutes.remainder(60));
    final seconds = twoDigits(duration.inSeconds.remainder(60));
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    _clearMusicNotifications();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0015),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded, color: Color(0xFFFF0040)),
          onPressed: () {
            _clearMusicNotifications();
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'Music Player',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.w800,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1A0025),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Row(
              children: [
                _buildTabButton(0, 'Search'),
                _buildTabButton(1, 'Downloads'),
              ],
            ),
          ),
          Expanded(
            child: _currentTab == 0 ? _buildSearchTab() : _buildDownloadsTab(),
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(int index, String text) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            _currentTab = index;
          });
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: _currentTab == index ? const Color(0xFFFF0040) : Colors.transparent,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: _currentTab == index ? Colors.white : const Color(0xFF888888),
              fontWeight: FontWeight.w700,
              fontSize: 14,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(25),
            decoration: BoxDecoration(
              color: const Color(0x101A0025),
              borderRadius: BorderRadius.circular(25),
              border: Border.all(color: const Color(0x30FFFFFF)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 30,
                  spreadRadius: 2,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Column(
              children: [
                const Row(
                  children: [
                    Icon(Icons.search_rounded, color: Color(0xFFFF0040), size: 28),
                    SizedBox(width: 12),
                    Text(
                      'SEARCH MUSIC',
                      style: TextStyle(
                        color: Color(0xFFFF0040),
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 25),
                TextField(
                  controller: _searchController,
                  style: const TextStyle(
                    color: Colors.white, 
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                  decoration: InputDecoration(
                    labelText: 'Search Music',
                    labelStyle: const TextStyle(
                      color: Color(0xFF888888),
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: const Color(0x20FFFFFF),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0xFFFF0040),
                        width: 2,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: const BorderSide(
                        color: Color(0x30FFFFFF),
                      ),
                    ),
                    prefixIcon: const Icon(
                      Icons.search_rounded,
                      color: Color(0xFFFF0040),
                      size: 22,
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 20,
                      vertical: 18,
                    ),
                  ),
                ),
                const SizedBox(height: 20),

                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _searchMusic,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFF0040),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      elevation: 8,
                      shadowColor: const Color(0xFFFF0040).withOpacity(0.5),
                    ),
                    child: _isLoading
                        ? const SizedBox(
                            height: 24,
                            width: 24,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 3,
                            ),
                          )
                        : const Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.search_rounded, size: 24),
                              SizedBox(width: 12),
                              Text(
                                'SEARCH MUSIC',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  fontSize: 16,
                                  letterSpacing: 1,
                                ),
                              ),
                            ],
                          ),
                  ),
                ),

                if (_errorMessage.isNotEmpty) ...[
                  const SizedBox(height: 20),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0x20FF0040),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: const Color(0xFFFF0040)),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.error_outline_rounded,
                          color: Color(0xFFFF0040),
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Text(
                            _errorMessage,
                            style: const TextStyle(
                              color: Color(0xFFFF0040),
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),

          const SizedBox(height: 20),
          if (_currentMusic != null) ...[
            Container(
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                color: const Color(0x101A0025),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: const Color(0x30FFFFFF)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 30,
                    spreadRadius: 2,
                    offset: const Offset(0, 15),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Row(
                        children: [
                          Icon(Icons.play_arrow_rounded, color: Color(0xFFFF0040), size: 24),
                          SizedBox(width: 10),
                          Text(
                            'NOW PLAYING',
                            style: TextStyle(
                              color: Color(0xFFFF0040),
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                        ],
                      ),
                      IconButton(
                        onPressed: _isDownloading ? null : _downloadMusic,
                        icon: _isDownloading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: Color(0xFFFF0040),
                                  strokeWidth: 2,
                                ),
                              )
                            : const Icon(Icons.download_rounded, color: Color(0xFFFF0040)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  
                  if (_thumbnailUrl != null && _thumbnailUrl!.isNotEmpty)
                    Container(
                      width: double.infinity,
                      height: 180,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15),
                        image: DecorationImage(
                          image: NetworkImage(_thumbnailUrl!),
                          fit: BoxFit.cover,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.5),
                            blurRadius: 10,
                            spreadRadius: 2,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                    ),
                  
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _currentMusic!['title'] ?? 'Unknown',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w800,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (_currentMusic!['author'] != null) ...[
                          const SizedBox(height: 8),
                          Text(
                            'Artist: ${_currentMusic!['author']}',
                            style: const TextStyle(
                              color: Color(0xFF888888),
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 20),
                  Column(
                    children: [
                      Slider(
                        value: _position.inSeconds.toDouble(),
                        min: 0,
                        max: _duration.inSeconds.toDouble(),
                        onChanged: _seekTo,
                        activeColor: const Color(0xFFFF0040),
                        inactiveColor: const Color(0xFF888888),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            _formatDuration(_position),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          Text(
                            _formatDuration(_duration),
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        onPressed: _stopMusic,
                        icon: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF0040).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
                          ),
                          child: const Icon(
                            Icons.stop_rounded,
                            color: Color(0xFFFF0040),
                            size: 28,
                          ),
                        ),
                      ),
                      const SizedBox(width: 20),
                      IconButton(
                        onPressed: _isPlaying ? _pauseMusic : () => _playMusic(_currentMusic!['mp3']),
                        icon: Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF0040),
                            borderRadius: BorderRadius.circular(50),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFFF0040).withOpacity(0.5),
                                blurRadius: 15,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Icon(
                            _isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded,
                            color: Colors.white,
                            size: 32,
                          ),
                        ),
                      ),
                      const SizedBox(width: 20),
                      IconButton(
                        onPressed: () => _playMusic(_currentMusic!['mp3']),
                        icon: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF0040).withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
                          ),
                          child: const Icon(
                            Icons.replay_rounded,
                            color: Color(0xFFFF0040),
                            size: 28,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
          ],
          if (_searchHistory.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                color: const Color(0x101A0025),
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: const Color(0x30FFFFFF)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.6),
                    blurRadius: 30,
                    spreadRadius: 2,
                    offset: const Offset(0, 15),
                  ),
                ],
              ),
              child: Column(
                children: [
                  const Row(
                    children: [
                      Icon(Icons.history_rounded, color: Color(0xFFFF0040), size: 24),
                      SizedBox(width: 10),
                      Text(
                        'SEARCH HISTORY',
                        style: TextStyle(
                          color: Color(0xFFFF0040),
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 15),
                  ..._searchHistory.map((history) => GestureDetector(
                    onTap: () {
                      if (history['musicData'] != null) {
                        setState(() {
                          _currentMusic = history['musicData'];
                          _thumbnailUrl = history['musicData']['thumbnail'];
                        });
                        _playMusic(history['musicData']['mp3']);
                      }
                    },
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white.withOpacity(0.1)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.music_note_rounded, color: Color(0xFFFF0040), size: 16),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  history['title'],
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                Text(
                                  'Searched: ${history['query']}',
                                  style: const TextStyle(
                                    color: Color(0xFF888888),
                                    fontSize: 10,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.play_arrow_rounded, color: Color(0xFFFF0040), size: 16),
                        ],
                      ),
                    ),
                  )).toList(),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildDownloadsTab() {
    return _downloadedMusic.isEmpty
        ? const Center(
            child: Text(
              'No downloaded music',
              style: TextStyle(
                color: Color(0xFF888888),
                fontSize: 16,
                fontWeight: FontWeight.w600,
              ),
            ),
          )
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _downloadedMusic.length,
            itemBuilder: (context, index) {
              final music = _downloadedMusic[index];
              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF1A0025),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: const Color(0xFFFF0040).withOpacity(0.3)),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.music_note_rounded, color: Color(0xFFFF0040), size: 20),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            music['title'],
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 14,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Downloaded',
                            style: const TextStyle(
                              color: Color(0xFF888888),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      children: [
                        IconButton(
                          onPressed: () => _playDownloadedMusic(music['path']),
                          icon: const Icon(Icons.play_arrow_rounded, color: Color(0xFFFF0040)),
                        ),
                        IconButton(
                          onPressed: () => _deleteDownloadedMusic(music['path']),
                          icon: const Icon(Icons.delete_rounded, color: Color(0xFFFF0040)),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          );
  }
}